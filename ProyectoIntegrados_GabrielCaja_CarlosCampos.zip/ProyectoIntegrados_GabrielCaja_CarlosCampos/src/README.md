La clase del MenuPrincipalRecursos.java es la clase main
